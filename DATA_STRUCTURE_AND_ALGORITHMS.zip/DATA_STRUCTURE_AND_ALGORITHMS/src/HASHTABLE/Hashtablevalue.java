package HASHTABLE;

import java.util.Hashtable;

public class Hashtablevalue {
 public static void main(String[] args) {
	 
	 //hastable func
	 Hashtable<Integer, Integer>  ht = new Hashtable<Integer, Integer>();
	 
	 //data
	 ht.put(123, 432);
     ht.put(12, 2345);
     ht.put(1500, 5643);
     ht.put(3, 321);
     
     //this is the value of the key
     int keymissing=1500;
     
     //if it constain the right key
     if(ht.containsKey(keymissing)) {
    	 System.out.println("Key found");
     }
     //else it does not contains the right key
     else {
    	 System.out.println("Key not found");
     }
 }
}
