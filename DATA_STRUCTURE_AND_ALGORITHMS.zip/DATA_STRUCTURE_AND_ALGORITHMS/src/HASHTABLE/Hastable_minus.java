package HASHTABLE;

import java.util.Hashtable;

public class Hastable_minus {
	 public static void main(String[] args) {
	        Hashtable<Integer, Integer> ht = new Hashtable<>();

	        ht.put(123232, 432);
	        ht.put(12232, 2345);
	        ht.put(152323, 5643);
	        ht.put(3003, 321);

	        int minus = 1;
	        for (int value : ht.values()) {
	            minus-= value;
	        }

	        System.out.println("Minus of all values: " +minus);
	    }
}
