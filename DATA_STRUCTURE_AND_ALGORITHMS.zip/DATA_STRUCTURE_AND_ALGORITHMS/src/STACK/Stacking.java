package STACK;

class Stacking {
	
	//our variables
    private int[] array;
    private int top;
    private int capacity;
    
   Stacking(int size) {
	 //our variables
        array = new int[size];
        capacity = size;
        top = -1;
    }
    
   //push function
    public void push(int x) {
    	
    	//if full the result will go here
        if (isFull()) {
            System.out.println("Overflow: Stack is full.");
            System.exit(1);
        }
        System.out.println("Inserting " + x);
        array[++top] = x;
    }
    //pop function
    public int pop() {
    	//if empty the result will go here
        if (isEmpty()) {
            System.out.println("Underflow: Stack is empty.");
            System.exit(1);
        }
        return array[top--];
    }
    
    //size
    public int size() {
        return top + 1;
    }
    
    // our function to isEmpty we use boolean 
    public boolean isEmpty() {
        return top == -1;
    }
    
 // our function to isFull we use boolean 
    public boolean isFull() {
        return top == capacity - 1;
    }
    
    //our function to printStack
    public void printStack() {
        if (isEmpty()) {
            System.out.println("Stack is empty.");
            return;
        }
        System.out.println("Stack elements:");
        
        // we use for loop to see value of stacking of LIFO
        for (int i = top; i >= 0; i--) {
        	
            System.out.println(array[i]);
        }
    }
    
    public static void main(String[] args) {
    	
    	// stack variable
        Stacking stack = new Stacking(10);
        
        //stack function
        stack.push(1);
        stack.push(2);
        stack.push(3);
        stack.push(4);
        stack.push(5);
        
        stack.pop();
        
        System.out.println("\nAfter popping out:");
        stack.printStack();
    }
}