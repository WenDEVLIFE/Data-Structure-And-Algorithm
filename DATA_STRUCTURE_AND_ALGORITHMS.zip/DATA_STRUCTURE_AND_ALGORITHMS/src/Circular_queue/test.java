package Circular_queue;

//
// 7 out 10
// by CHATGPT

/*I would rate your implementation of the circular queue a 7 out of 10. You have successfully implemented the core functionality of the circular queue, including enqueue, dequeue, isEmpty, and isFull operations. The logic and flow of the code appear to be correct.

However, there are a few areas for improvement:00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
Naming conventions: It's a good practice to follow standard naming conventions in Java. Class names should start with an uppercase letter, so consider renaming your class from test to Test to adhere to the conventions.

Encapsulation: It's beneficial to encapsulate your data members (size, front, rear, and mytems) by making them private and providing appropriate getter and setter methods if necessary. This helps in maintaining encapsulation and ensures proper access to the data members.

Error handling: In your current implementation, when the circular queue is full and an enqueue operation is attempted, you only print a message indicating that the queue is full. It might be helpful to return a boolean value indicating the success/failure of the enqueue operation.

Code documentation: Adding comments to your code can greatly improve its readability and maintainability. Consider adding comments to explain the purpose of methods, their parameters, and their return values. It will make your code more understandable for others (and even for yourself in the future).

Taking these improvements into account, your implementation will become even more robust and maintainable. Keep up the good work!
*/

public class test {
	/*
	 * this is also the mistakes
	Encapsulation: It's beneficial to encapsulate your data members (size, front, rear, and mytems)
	 by making them private and providing appropriate getter and setter methods if necessary.
	 This helps in maintaining encapsulation and ensures proper access to the data members.
	 example:
	private int size;
    private int front;
    private int rear;
    private int[] mytems;
    
    */
	
	// varialbes
	int size=3;
	int front, rear;
	int mytems[]= new int[size];
	
	test() {
		front=-1;
		rear=-1;
	}
	boolean isFull() {
		// my mistake is here 
		//instead using nested loop put the function in 1 function thatn creating a 2 function to avoid issues.
		/*
		 * 
		if ((front == 0 && rear == size - 1) || (front == rear + 1)) {
	            return true;
	     }
	    */
		
		if (front==0&&rear==size-1) {
		return true;
		}
		if (front==rear+1) {
			return true;
		}
		return false;
	}
	
	boolean isEmpty() {
		if (front==-1) { 
			return true;
		}
		else {
		return false;
		}
	}
	
    void Enqueue(int element){
    	// if the queue is full
    	if(isFull()) {
    		System.out.println("Queue is full");
    		//else if its empty it will insert a value
    	} else {
    		if(front==-1)
    			front=0;
    		rear=(rear+1) % size;
    		mytems[rear]=element;
    		System.out.println("Inserted" + element);
    	}
    	
    	
    }
    
    // Removing an element
    int deQueue() {
      int element;
      if (isEmpty()) {
        System.out.println("Queue is empty");
        return (-1);
      } else {
        element = mytems[front];
        if (front == rear) {
        	front = -1;
        	rear = -1;
        } /* Q has only one element, so we reset the queue after deleting it. */
        else {
        	front = (front + 1) % size;
        }
        return (element);
      }
    }
    
      void display() {
    	    /* Function to display status of Circular Queue */
    	    int i;
    	    if (isEmpty()) {
    	      System.out.println("Empty Queue");
    	    } else {
    	      System.out.println("Front -> " + front);
    	      System.out.println("Items -> ");
    	      for (i = front; i != rear; i = (i + 1) % size)
    	        System.out.print(mytems[i] + " ");
    	      System.out.println(mytems[i]);
    	      System.out.println("Rear -> " + rear);
    	    }
    	  }

    	  public static void main(String[] args) {

    		  //circular queue variable
    	    circular q = new circular();

    	    // Fails because front = -1
    	    q.deQueue();

    	    //insert a value
    	    q.Enqueue(1);
    	    q.Enqueue(2);
    	    q.Enqueue(3);
    	 
    	 
    	    

    	    //display void display
    	    q.display();

    	   
    	  }


}
