package Circular_queue;

public class circular {

	int SIZE=20;
	int FRONT, REAR;
	int items[] = new int [SIZE];
	circular(){
		FRONT=-1;
		REAR=-1;
		
	}
	boolean isFull() {
		if (FRONT==0&&REAR==SIZE-1) {
		return true;
		}
		if (FRONT==REAR+1) {
			return true;
		}
		return false;
	}
	
	boolean isEmpty() {
		if (FRONT==-1) { 
			return true;
		}
		else {
		return false;
		}
	}
	
    void Enqueue(int element){
    	if(isFull()) {
    		System.out.println("Queue is full");
    	} else {
    		if(FRONT==-1)
    			FRONT=0;
    		REAR=(REAR+1) % SIZE;
    		items[REAR]=element;
    		System.out.println("Inserted" + element);
    	}
    	
    	
    }
    
    // Removing an element
    int deQueue() {
      int element;
      if (isEmpty()) {
        System.out.println("Queue is empty");
        return (-1);
      } else {
        element = items[FRONT];
        if (FRONT == REAR) {
        	FRONT = -1;
        	REAR = -1;
        } /* Q has only one element, so we reset the queue after deleting it. */
        else {
        	FRONT = (FRONT + 1) % SIZE;
        }
        return (element);
      }
    }
    
      void display() {
    	    /* Function to display status of Circular Queue */
    	    int i;
    	    if (isEmpty()) {
    	      System.out.println("Empty Queue");
    	    } else {
    	      System.out.println("Front -> " + FRONT);
    	      System.out.println("Items -> ");
    	      for (i = FRONT; i != REAR; i = (i + 1) % SIZE)
    	        System.out.print(items[i] + " ");
    	      System.out.println(items[i]);
    	      System.out.println("Rear -> " + REAR);
    	    }
    	  }

    	  public static void main(String[] args) {

    	    circular q = new circular();

    	    // Fails because front = -1
    	    q.deQueue();

    	    q.Enqueue(1);
    	    q.Enqueue(2);
    	    q.Enqueue(3);
    	    q.Enqueue(4);
    	    q.Enqueue(5);
    	    q.Enqueue(6);
    	    q.Enqueue(7);
    	    q.Enqueue(8);
    	    q.Enqueue(9);
    	    q.Enqueue(10);
    	    q.Enqueue(11);
    	    q.Enqueue(12);
    	    q.Enqueue(13);
    	    q.Enqueue(14);
    	    q.Enqueue(15);
    	    q.Enqueue(16);
    	    q.Enqueue(17);
    	    q.Enqueue(18);
    	    q.Enqueue(19);
    	    q.Enqueue(20);
    	    // Fails to enqueue because front == 0 && rear == SIZE - 1
    	    q.Enqueue(21);

    	    q.display();

    	    int elem = q.deQueue();

    	    if (elem != -1) {
    	      System.out.println("Deleted Element is " + elem);
    	    }
    	    q.display();

    	    q.Enqueue(22);

    	    q.display();

    	    // Fails to enqueue because front == rear + 1
    	    q.Enqueue(23);
    	  }

    

}