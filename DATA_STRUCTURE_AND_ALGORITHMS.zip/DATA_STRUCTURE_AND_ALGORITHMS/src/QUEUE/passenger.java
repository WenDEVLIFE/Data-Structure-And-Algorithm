package QUEUE;

public class passenger {
    // our variables
    int space = 10;
    int seats[] = new int[space];
    int infront, back;

    passenger() {
    	
        infront = -1;
        back = -1;
    }

    boolean isFull() {
        if (infront == 0 && back == space - 1) {
            return true;
        }
        return false;
    }

    boolean isEmpty() {
        if (infront == -1)
            return true;
        else
            return false;
    }

    void enQueue(int passenger) {
        if (isFull()) {
            System.out.println("The bus is full");
        } else {
            if (infront == -1)
                infront = 0;
            back++;
            seats[back] = passenger;
            System.out.println("Inserted passenger " + passenger);
        }
    }

    int deQueue() {
        int passenger;
        if (isEmpty()) {
            System.out.println("The seats is empty");
            return (-1);
        } else {
        	passenger = seats[infront];
            if (infront >= back) {
                infront = -1;
                back = -1;
            } /* Q has only one element, so we reset the queue after deleting it. */
            else {
                infront++;
            }
            System.out.println("Passenger 11 cancelled his ticket -> " + passenger);
            return (passenger);
        }
    }

    void display() {
        /* Function to display elements of Queue */
        int i;
        if (isEmpty()) {
            System.out.println("Empty Queue of Passenger");
        } else {
            System.out.println("\nFront seats -> " + infront);
            System.out.println("Seats -> ");
            for (i = infront; i <= back; i++)
                System.out.print(seats[i] + "  ");
            System.out.println("\n Backseats of the bus occupied-> " + back);
        }
    }

    public static void main(String[] args) {
    	System.out.println("---------------------------------");
    	System.out.println(" Welcome to Ecoland Transporation");
    	System.out.println("---------------------------------");

        passenger q = new passenger();

        // deQueue is not possible on an empty queue
        q.deQueue();

        // enQueue 10 passenger
        q.enQueue(1);
        q.enQueue(2);
        q.enQueue(3);
        q.enQueue(4);
        q.enQueue(5);
        q.enQueue(6);
        q.enQueue(7);
        q.enQueue(8);
        q.enQueue(9);
        q.enQueue(10);

        // 11 passenger cannot be add due to full
        q.enQueue(11);

        q.display();

        // deQueue removes the element entered first i.e., 1
        q.deQueue();

        // Now we have just 10 passenger
        q.display();
        
        System.out.println("------------------------------------------------");
        System.out.println(" Thank you for choosing ecoland transportation");
        System.out.println("------------------------------------------------");
    }
}

       