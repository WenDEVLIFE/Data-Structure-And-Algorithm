package QUEUE;

public class Queue {

	
		
		int s=5;
		int it[]= new int[s];
		int fr, r;

		
		Queue() {
			fr =-1;
			r=-1;
		}
		boolean isFull() {
			if (fr == 0 && r == s - 1) {
			      return true;
			    }
			    return false;
		}
		 boolean isEmpty() {
			    if (fr == -1)
			      return true;
			    else
			      return false;
			  }
		 void enQueue(int element) {
			    if (isFull()) {
			      System.out.println("Queue is full");
			    } else {
			      if (fr == -1)
			        fr= 0;
			      r++;
			      it[r] = element;
			      System.out.println("Inserted " + element);
			    }
		 }
		 
			    
			    int deQueue() {
			        int element;
			        if (isEmpty()) {
			          System.out.println("Queue is empty");
			          return (-1);
			        } else {
			          element = it[fr];
			          if (fr >= r) {
			            fr = -1;
			            r = -1;
			          } /* Q has only one element, so we reset the queue after deleting it. */
			          else {
			            fr++;
			          }
			          System.out.println("Deleted -> " + element);
			          return (element);
			        }
			        }
			        void display() {
			            /* Function to display elements of Queue */
			            int i;
			            if (isEmpty()) {
			              System.out.println("Empty Queue");
			            } else {
			              System.out.println("\nFront index-> " + fr);
			              System.out.println("Items -> ");
			              for (i = fr; i <= r; i++)
			                System.out.print(it[i] + "  ");
			            

			              System.out.println("\nRear index-> " + r);
			            }
			          
			    }
		 
			    
			    public static void main(String[] args) {
			    	 Queue q = new Queue();
			    	 // deQueue is not possible on empty queue
			    	    q.deQueue();

			    	    // enQueue 5 elements
			    	    q.enQueue(1);
			    	    q.enQueue(2);
			    	    q.enQueue(3);
			    	    q.enQueue(4);
			    	    q.enQueue(5);

			    	    // 6th element can't be added to because the queue is full
			    	    q.enQueue(6);

			    	    q.display();

			    	    // deQueue removes element entered first i.e. 1
			    	    q.deQueue();

			    	    // Now we have just 4 elements
			    	    q.display();
			    }
			    
	}


