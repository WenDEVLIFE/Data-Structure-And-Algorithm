package algorithms;
import java.util.Scanner;
public class add_two_numbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
// Scanner variable
 Scanner math = new Scanner (System.in);
 
 // Enter a first number
 System.out.println("ENTER A FIRST NUMBER");
 int num1 = math.nextInt();
 
 // Enter a second number
 System.out.println("ENTER A Second NUMBER");
 int num2 = math.nextInt();
 
 // add the value of num1 and num2
 int sum = num1 + num2;
 
 // Print the sum //
 System.out.println("The sum is:" + sum);
 
	}

}
