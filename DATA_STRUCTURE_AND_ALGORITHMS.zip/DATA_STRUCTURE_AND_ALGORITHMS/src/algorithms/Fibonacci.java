package algorithms;

public class Fibonacci {
    public static void main(String[] args) {
        int firstTerm = 0;
        int secondTerm = 1;
        
        // Display the first two terms of the Fibonacci sequence
        System.out.println(firstTerm);
        System.out.println(secondTerm);
        
        // Calculate and display the remaining terms of the Fibonacci sequence
        while (secondTerm <= 1000) {
            int temp = secondTerm;
            secondTerm = secondTerm + firstTerm;
            firstTerm = temp;
            System.out.println(secondTerm);
        }
    }
}
