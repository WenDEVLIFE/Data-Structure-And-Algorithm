package algorithms;

import java.util.Scanner;

public class QuadraticEquation {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        System.out.print("Enter the coefficient of x^2 (a): ");
        double a = input.nextDouble();
        
        System.out.print("Enter the coefficient of x (b): ");
        double b = input.nextDouble();
        
        System.out.print("Enter the constant term (c): ");
        double c = input.nextDouble();
        
        // Calculate the discriminant
        double discriminant = b * b - 4 * a * c;
        
        // Check if discriminant is non-negative (real roots)
        if (discriminant >= 0) {
            // Calculate the real roots
            double root1 = (-b + Math.sqrt(discriminant)) / (2 * a);
            double root2 = (-b - Math.sqrt(discriminant)) / (2 * a);
            
            // Display the real roots
            System.out.println("Root 1: " + root1);
            System.out.println("Root 2: " + root2);
        } else {
            // Calculate the real and imaginary parts of the complex roots
            double realPart = -b / (2 * a);
            double imaginaryPart = Math.sqrt(-discriminant) / (2 * a);
            
            // Display the complex roots
            System.out.println("Root 1: " + realPart + " + " + imaginaryPart + "i");
            System.out.println("Root 2: " + realPart + " - " + imaginaryPart + "i");
        }
    }
}