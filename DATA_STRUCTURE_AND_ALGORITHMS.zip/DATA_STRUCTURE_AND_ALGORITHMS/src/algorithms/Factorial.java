package algorithms;

import java.util.Scanner;

public class Factorial {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        // Prompt the user to enter a number
        System.out.print("Enter a number: ");
        int n = input.nextInt();
        
        // Initialize variables
        int factorial = 1;
        int i = 1;
        
        // Calculate factorial using a loop
        while (i <= n) {
            factorial *= i; // Multiply factorial by i
            i++; // Increment i by 1
        }
        
        // Display the factorial
        System.out.println("Factorial of " + n + " is: " + factorial);
    }
}
