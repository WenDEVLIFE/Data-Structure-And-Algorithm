package algorithms;

import java.util.Scanner;

public class LargestNumber {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        // ask to put a first number
        System.out.print("Enter the first number (a): ");
        int a = input.nextInt();
        
        // ask to put a second number
        System.out.print("Enter the second number (b): ");
        int b = input.nextInt();
        
        // ask to put a third number
        System.out.print("Enter the third number (c): ");
        int c = input.nextInt();
        
        // if a is greater than b
        if (a > b) {
        	
        	// if a is greater than c
            if (a > c) {
            	
            	//print a is the largest
                System.out.println(a + " is the largest number.");
                
               
            } else {
            	 // print c is the largest than a
                System.out.println(c + " is the largest number.");
            }
            
        } else {
        	
         	// if b is greater than c
            if (b > c) {
            	
            	//print b is the largest number
                System.out.println(b + " is the largest number.");
             	
            } 
         // if c is greater than b
            else {
            	
            	//print the c is largest number than b
                System.out.println(c + " is the largest number.");
            }
        }
    }
}
