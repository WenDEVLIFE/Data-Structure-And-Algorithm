package algorithms;

import java.util.Scanner;

public class PrimeNumber {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        // Prompt the user to enter a number
        System.out.print("Enter a number: ");
        int n = input.nextInt();
        
        // Initialize variables
        int flag = 1;
        int i = 2;
        
        // Check if the number is prime using a loop
        while (i <= n / 2) {
            if (n % i == 0) {
                flag = 0; // Set flag to 0 if a factor is found
                break; // Exit the loop
            }
            i++; // Increment i by 1
        }
        
        // Check the value of flag to determine if the number is prime or not
        if (flag == 0) {
            System.out.println(n + " is not a prime number.");
        } else {
            System.out.println(n + " is a prime number.");
        }
    }
}