package deque;


class deque {
	//variables
  public static final int M=100;
  private int arr[];
  private int front;
  private int rear;
  private int size;
  
  //deque function
  public deque (int size) {
	  arr= new int[M];
	  front =-1;
	  rear=0;
	  this.size=size;
  }
  //boolean isfull function
  boolean isFULL() {
	  return((front==0&&rear==size-1||front==rear+1));
  }
  //boolean isempty function
  boolean isEMPTY() {
	  return (front==-1);
  }
  
  //void insertfront
  void insertfront(int key) {
	  if (isFULL()) {
	      System.out.println("Overflow");
	      return;
	    }
	  if (front==-1) {
		  front=0;
		  rear=0;
		  
	  }
	  
	  else if (front==0) 
		  front = size - 1;
	  else 
		  front = front - 1;
	  arr[front]=key;
  }
  
  //void insertrear
  void insertrear(int key) {
	    if (isFULL()) {
	      System.out.println(" Overflow ");
	      return;
	    }

	    if (front == -1) {
	      front = 0;
	      rear = 0;
	    }

	    else if (rear == size - 1)
	      rear = 0;

	    else
	      rear = rear + 1;

	    arr[rear] = key;
	  }
  
  // void deletefront
  void deletefront() {
	    if (isEMPTY()) {
	      System.out.println("Queue Underflow\n");
	      return;
	    }

	    // Deque has only one element
	    if (front == rear) {
	      front = -1;
	      rear = -1;
	    } else if (front == size - 1)
	      front = 0;

	    else
	      front = front + 1;
	  }
  
  //void delete rear function
  void deleterear() {
	    if (isEMPTY()) {
	      System.out.println(" Underflow");
	      return;
	    }

	    if (front == rear) {
	      front = -1;
	      rear = -1;
	    } else if (rear == 0)
	      rear = size - 1;
	    else
	      rear = rear - 1;
	  }
  // void getFront
  int getFront() {
	  
	  // if the value is empty
	    if (isEMPTY()) {
	    	  
	  	  // if the value is empty
	      System.out.println(" Underflow");
	      return -1;
	    }
	    return arr[front];
	  }
  
  // void getRear
  int getRear() {
	    if (isEMPTY() || rear < 0) {
	      System.out.println(" Underflow\n");
	      return -1;
	    }
	    return arr[rear];
	  }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		

		
		// value of its index
	    deque dq = new deque(4);

	    //insert 12
	    System.out.println("Insert element at rear end : 12 ");
	    dq.insertrear(12);

	    //insert 14
	    System.out.println("insert element at rear end : 14 ");
	    dq.insertrear(14);

	    //get the rear element value
	    System.out.println("get rear element : " + dq.getRear());

	    //delete the rear value
	    dq.deleterear();
	    System.out.println("After delete rear element new rear become : " + dq.getRear());

	    //insert 13
	    System.out.println("inserting element at front end");
	    dq.insertfront(13);

	    //get the value of void front
	    System.out.println("get front element: " + dq.getFront());

	    //delete front value
	    dq.deletefront();

	    //print the new front value
	    System.out.println("After delete front element new front become : " + +dq.getFront());

	}

}
