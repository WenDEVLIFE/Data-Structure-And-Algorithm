package MASTER_THEOREM;

public class Master_THEOREM_PROBLEM {
	
	public static long rf(long n) {
		   // Base case
		if(n<=1) {
			return 1;
		}
		
	    // Recursive function call
		long spsize = n / 2;
		long spcount = 3;
		
	    // Recursively solve the subproblem
		long sum =0;
		
		for( int i=0; i<spcount; i++) {
			long spsolution = rf(spsize);
			sum+=spsolution;
		}
		
		  // Additional work outside the recursive calls
		long addwork = addwork(n);
		
		return sum + addwork;
	}
	
	public static long addwork(long n) {
		// Perform the additional work here
	    // This can include any computations or operations on the input size 'n'
	    // You can modify this method according to your specific needs.
		return n* n; // Additional work of n^2 complexity
	}
	public static void main (String [] args) {
		
		long inpsize = 16; // Specify the size of the input here
		 
		long output = rf(inpsize);
		
		System.out.println("Output is:" + output);
	}

}
