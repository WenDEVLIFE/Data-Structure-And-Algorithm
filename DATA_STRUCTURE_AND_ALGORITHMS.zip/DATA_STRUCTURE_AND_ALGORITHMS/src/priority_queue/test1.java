package priority_queue;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.PriorityQueue;

public class test1 {
    public static List<Integer> mergeKLists(List<List<Integer>> lists) {
        PriorityQueue<Integer> priorityQueue = new PriorityQueue<>();

        // Add all elements to the priority queue
        for (List<Integer> list : lists) {
            priorityQueue.addAll(list);
        }

        List<Integer> mergedList = new ArrayList<>();

        // Remove the smallest element from the priority queue and add it to the merged list
        while (!priorityQueue.isEmpty()) {
            mergedList.add(priorityQueue.poll());
        }

        return mergedList;
    }

    public static void main(String[] args) {
        List<List<Integer>> lists = new ArrayList<>();
        lists.add(Arrays.asList(1, 4, 5));
        lists.add(Arrays.asList(1, 3, 4));
        lists.add(Arrays.asList(2, 6));

        List<Integer> mergedList = mergeKLists(lists);
        System.out.println("Merged List: " + mergedList);
    }
}
