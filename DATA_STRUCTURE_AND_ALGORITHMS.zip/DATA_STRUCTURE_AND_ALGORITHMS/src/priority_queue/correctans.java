package priority_queue;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;

public class correctans {
    public static List<Integer> findKFrequentElements(int[] nums, int k) {
        // Step 1: Create a frequency map to store the count of each element
        Map<Integer, Integer> frequencyMap = new HashMap<>();
        for (int num : nums) {
            frequencyMap.put(num, frequencyMap.getOrDefault(num, 0) + 1);
        }

        // Step 2: Create a priority queue with a custom comparator to store entries based on their frequency counts
        PriorityQueue<Map.Entry<Integer, Integer>> priorityQueue = new PriorityQueue<>(
                (a, b) -> a.getValue() - b.getValue()
        );

        // Step 3: Iterate over the entries in the frequency map and add them to the priority queue
        for (Map.Entry<Integer, Integer> entry : frequencyMap.entrySet()) {
            priorityQueue.offer(entry);

            // If the size of the priority queue exceeds k, remove the entry with the smallest frequency count
            if (priorityQueue.size() > k) {
                priorityQueue.poll();
            }
        }

        // Step 4: Extract the elements from the priority queue in reverse order and store them in a list
        List<Integer> result = new ArrayList<>();
        while (!priorityQueue.isEmpty()) {
            result.add(priorityQueue.poll().getKey());
        }

        // Step 5: Reverse the list to get the elements in descending order of frequency
        Collections.reverse(result);
        return result;
    }

    public static void main(String[] args) {
        // Sample input
        int[] nums = {1, 1, 1, 2, 2, 3};
        int k = 2;

        // Step 6: Call the findKFrequentElements method to get the k most frequent elements
        List<Integer> frequentElements = findKFrequentElements(nums, k);

        // Step 7: Print the result
        System.out.println("The " + k + " most frequent elements are: " + frequentElements);
    }
}