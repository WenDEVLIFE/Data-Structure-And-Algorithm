package priority_queue;

import java.util.PriorityQueue;

public class test2 {
	public static int fqElement(int[] nums, int k) {
        PriorityQueue<Integer> priorityQueue = new PriorityQueue<>();

        // for int num : nums
        for (int num : nums) {
        	// which will priorityqueue the num
            priorityQueue.offer(num);

            // if the size is less than num
            if (priorityQueue.size() < num) {
            	// it will display 1
                priorityQueue.poll();
            }
        }

        // go back
        return priorityQueue.peek();
    }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// variables
		int[] nums = { 1, 1, 1, 2, 2, 3} ;
		int k = 2;
		 
		//find the element
		int Element= fqElement(nums , k);
		
		//print the value
		System.out.println("The 2 most frequent elements are " + Element + " and " + k);
	}

}
