package linkedlist;

public class TESTLINKEDLIST {
	static String message = "The Nodes are ---> ";
	Node Ulo;
	
	static class Node {
		
		private int label;
		private Node sunod;
		
		Node(int labelnemo){
			label = labelnemo;
			sunod = null;
		}
	}	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Linked List Variable
		TESTLINKEDLIST TESTLINKEDLIST1 = new TESTLINKEDLIST ();
		
		 // Assign value values
		TESTLINKEDLIST1.Ulo = new Node(0);
		Node one = new Node(1);
		Node two = new Node(2);
		Node three = new Node(3);
		Node four = new Node(4);
		Node five = new Node(5);
		Node six= new Node(6);
		Node seven = new Node(7);
		Node eight= new Node(8);
		Node nine= new Node(9);
		Node ten= new Node(10);
		
		//Connect the nodes
		
		TESTLINKEDLIST1.Ulo.sunod = one;
		one.sunod = two;
		two.sunod = three;
		three.sunod = four;
		four.sunod = five;
		five.sunod = six;
		six.sunod = seven;
		seven.sunod = eight;
	    eight.sunod = nine;
	    nine.sunod = ten;
	    
	    // printing node-value
	    while (TESTLINKEDLIST1.Ulo !=null) {
	    	System.out.println(message + TESTLINKEDLIST1.Ulo.label+ " ");
	    	TESTLINKEDLIST1.Ulo = TESTLINKEDLIST1.Ulo.sunod;
	    }
		
	}
	

}
