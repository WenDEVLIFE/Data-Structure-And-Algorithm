package DIVIDE_AND_CONQUER;

public class RegursiveAlgorithm1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		 // Pagsisimula ng recursive algorithm
		int r = recursivefunc(16);
		System.out.println("Ang result ay:" + r);

	}
	public static int recursivefunc(int n) {
		// Base case: Kung ang n ay maliit na sapat, hindi na natin kailangan magpatuloy sa recursion
		if (n<=1) {
			return 1;
		}
		
		 // Ang a ay ang bilang ng subproblema sa bawat rekursibong tawag.
		int A= 2;
		
        // Ang b ay ang sukat ng bawat subproblema. Sa halimbawang ito, ginagawa natin ang kalahati ng n sa bawat rekursibong tawag.
		int B=2;
		
		// Ang f(n) ay ang kusang gawain na ginagawa sa labas ng rekursibong tawag.
		int F = n + 1;
		
		// Pagsasagawa ng recursive calls
		int s=0;
		
		for (int i=0; i<A; i++) {
			// Ang recursiveFunction(n / b) ay ang rekursibong tawag sa bawat subproblema.
			s+=recursivefunc(n/B);
		}
		
		// Pagmamerge ng mga resulta ng subproblema
		int r= s + F;
		
		return r;
	}

}
