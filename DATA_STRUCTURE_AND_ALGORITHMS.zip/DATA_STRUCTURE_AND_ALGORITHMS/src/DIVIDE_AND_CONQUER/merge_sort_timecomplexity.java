package DIVIDE_AND_CONQUER;

import java.util.Arrays;

public class merge_sort_timecomplexity {


   public static int recursiveF(int[] ar) {
	   // Base case: Kung ang haba ng array ay maliit na sapat, hindi na natin kailangan magpatuloy sa recursion
		if (ar.length <=1) {
			return ar[0];
		}
		
		// Ang a ay 2 dahil hinahati natin ang problema sa dalawang subproblema sa bawat rekursibong tawag.
		int A=2;
		
		// Ang b ay 2 dahil ang sukat ng bawat subproblema ay kalahati ng haba ng input array.
		int B=2;
		
		 // Ang f(n) ay ang oras na kinakailangan upang hatiin ang problema at i-merge ang mga subproblema.
		int F=ar.length;
		
		 // Paghahati ng input array sa dalawang subarrays
		int middle = ar.length / 2;
		int[] leftsub = Arrays.copyOfRange(ar, 0, middle);
		int[] rightsub = Arrays.copyOfRange(ar, middle, ar.length);
		
		 // Recursive calls sa dalawang subarrays
		int s=0;
		s+=recursiveF(leftsub);
		s+=recursiveF(rightsub);
		
		// Pagmamerge ng mga resulta ng dalawang subarrays
		int r = s + F;
		
		return r;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	// Array index
   int[] ar = { 1, 2, 3, 4, 5, 6, 7, 8};
   
   // call the Method Recursive
   int r = recursiveF(ar);
  
   //print the result
   System.out.println("The result are:" + r);
	}
}
