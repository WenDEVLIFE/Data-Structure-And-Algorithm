package DIVIDE_AND_CONQUER;

public class Fibonacci_DIVIDE_AND_CONQUER_ALGORITHM {
	public static int fibonacci_sequence(int num) {
		  // Base case: Kung ang n ay mas maliit sa 2, ibabalik natin ang 1
		if (num <2) {
			return 1;
			
		}
		
		  // Rekurisibong tawag sa f(n - 1) at f(n - 2)
		int fminus1 = fibonacci_sequence( num - 1);
		int fminus2 = fibonacci_sequence( num - 2);
		
		 // Pagmamerge ng mga resulta
		int output = fminus1 + fminus2;
		
		return output;
	}
	
	
	
	
	
	
public static void main(String [] args) {
	
	int num= 6;
	
	int output = fibonacci_sequence(num);
	
	System.out.println("The output is:" + output);

}


}
