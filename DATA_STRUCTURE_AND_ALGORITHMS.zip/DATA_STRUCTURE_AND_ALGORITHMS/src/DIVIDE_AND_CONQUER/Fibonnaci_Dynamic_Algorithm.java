package DIVIDE_AND_CONQUER;

import java.util.Arrays;

public class Fibonnaci_Dynamic_Algorithm {
	
static int[] memory;
    public static int f(int num) {
    	// Base case: Kung ang n ay mas maliit sa 2, ibabalik natin ang 1
    	if (num <2) {
    		return 1;
    	}
    	
    	 // Kung ang resulta para sa n ay nasa memory, ibalik ang resulta mula sa memory
    	if (memory[num] !=-1) {
    		return memory[num];
    	}
    	
    	// Rekurisibong tawag sa f(n - 1) at f(n - 2)
    	int fminus1 = f(num-1);
      	int fminus2 = f(num-2);
    	
      	 // Pagmamerge ng mga resulta
      	int output = fminus1 + fminus2;
      	
        // I-save ang resulta sa memory para sa susunod na paggamit
      	memory[num]=output;
      	
      	return output;
    	
    }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num=6;
		
		memory = new int[num+1];  // Mag-reserve ng espasyo sa memory para sa memoization
	    Arrays.fill(memory, -1);  // Mag-reserve ng espasyo sa memory para sa memoization
	    
	    int output = f(num);
	    
	    System.out.println("Ang outout ay:" + output);

	}

}
