package ASYMPTOTIC_notations;

public class ThetaNotation {

    // Function to check if f(n) belongs to Θ(g(n))
    public static boolean isInTheta(int[] f, int[] g, int n0, double c1, double c2) {
    	
    	// if n0 is less than array f index length
        for (int i = n0; i < f.length; i++) {
        	
        	/*
        	if c1 multuply g and use the value the i looping to multiplyy  
        	and is greater than f vavlue or if  f value is greater than c2 multiply by g value
        	it will return false the result will be false
        
        	 */
            if (c1 * g[i] > f[i] || f[i] > c2 * g[i]) {
            	
            	//print false
                return false;
            }
        }
        //print true
        return true;
    }

    public static void main(String[] args) {
        int[] f = {2, 4, 8, 16, 32};  // Example f(n)
        int[] g = {1, 2, 3, 4, 5};    // Example g(n)
        
        // this connected in our for loop
        int n0 = 2;                   // n0 value
        
    
        double c1 = 0.5;              // c1 value
        double c2 = 0.5;              // c2 value

        // use boolean to check it is true or false
        boolean isInTheta = isInTheta(f, g, n0, c1, c2);
        System.out.println("f(n) belongs to Θ(g(n)): " + isInTheta);
    }
}
