package ASYMPTOTIC_notations;

public class OmegaNotation {

    // Function to check if f(n) belongs to Ω(g(n))
    public static boolean isInOmega(int[] f, int[] g, int n0, double c) {
        for (int i = n0; i < f.length; i++) {
            if (c * g[i] > f[i]) {
                return false;
            }
        }
        return true;
    }

    public static void main(String[] args) {
        int[] f = {2, 4, 8, 16, 32};  // Example f(n)
        int[] g = {1, 2, 3, 4, 5};    // Example g(n)
        int n0 = 2;                   // n0 value
        double c = 0.5;               // c value

        boolean isInOmega = isInOmega(f, g, n0, c);
        System.out.println("f(n) belongs to Ω(g(n)): " + isInOmega);
    }
}