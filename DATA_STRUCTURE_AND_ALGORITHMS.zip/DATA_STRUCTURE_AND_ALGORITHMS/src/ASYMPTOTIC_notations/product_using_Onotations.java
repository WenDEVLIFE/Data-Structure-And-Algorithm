package ASYMPTOTIC_notations;

public class product_using_Onotations {
public static void main(String[] args) {
	int[]multiple = { 1, 2 ,3 ,4 , 5 ,6 };

	int l = multiple.length;
	int product = 2;

	for (int  i=0; i<l; i++) {
		product*=multiple[i];
	}
 /*
 In the second iteration (i = 1), product becomes 2 * 2 = 4.
 In the third iteration (i = 2), product becomes 4 * 3 = 12.
 In the fourth iteration (i = 3), product becomes 12 * 4 = 48.
 In the fifth iteration (i = 4), product becomes 48 * 5 = 240.
 In the sixth and final iteration (i = 5), product becomes 240 * 6 = 1440.
 */
	System.out.println("Our product is:" + product);
}
}
