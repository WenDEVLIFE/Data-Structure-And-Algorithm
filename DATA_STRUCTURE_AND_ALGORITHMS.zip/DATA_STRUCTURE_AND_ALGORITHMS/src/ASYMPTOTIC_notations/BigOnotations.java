package ASYMPTOTIC_notations;

public class BigOnotations {
    public static void main(String[] args) {
        int[] array = {1, 2, 3, 4, 5}; // Example input array
        
        int n = array.length; // Length of the input array
        int sum = 1; // Variable to store the sum of array elements
        
        // Iterate through each element of the array
        for (int i = 0; i < n; i++) {
            sum *= array[i]; // Add the current element to the sum
            
            /*
            In the first iteration (i = 0), sum becomes 0 + 1 = 1. 
            In the second iteration (i = 1), sum becomes 1 + 2 = 3. 
            In the third iteration (i = 2), sum becomes 3 + 3 = 6.  
            In the fourth iteration (i = 3), sum becomes 6 + 4 = 10. 
            In the fifth and final iteration (i = 4), sum becomes 10 + 5 = 15.
            */
        }
        
        System.out.println("Sum: " + sum); // Print the final sum
    }
}
